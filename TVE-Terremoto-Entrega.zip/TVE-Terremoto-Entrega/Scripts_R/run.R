# Executar na raiz da entrega: Rscript Scripts_R/run.R
# Pacotes necessários: evd, jsonlite, sp. Produtos são gravados em Resultados/.
options(warn=1)
set.seed(20261029)
for(p in c('evd','jsonlite','sp')) if(!requireNamespace(p,quietly=TRUE))stop('Dependência ausente: ',p)
for(p in c('Resultados/processados','Resultados/tables','Resultados/figures'))dir.create(p,recursive=TRUE,showWarnings=FALSE)
# Produtos destes diretórios pertencem ao pipeline; limpar evita publicar análises removidas.
for(p in c('Resultados/tables','Resultados/figures')) unlink(list.files(p,pattern='\\.(csv|txt|png)$',full.names=TRUE))
source('Scripts_R/funcoes.R')
for(s in c('01_importacao','02_descritiva','03_blocos_gev','04_regional','06_mapas')){
 message('Executando ',s);source(paste0('Scripts_R/',s,'.R'))
}

writeLines(capture.output(sessionInfo()),'Resultados/tables/sessionInfo.txt')
saveRDS(list(global=global,regional=regional,blocks=models,region_names=region_names),'Resultados/processados/modelos.rds')
