"""Confere produtos contra os hashes da versão aprovada (mesma plataforma)."""
import hashlib,json,re
from pathlib import Path
base=Path('.')
manifest=json.loads(Path('tests/produtos_aprovados.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
tex=Path('relatorio.tex').read_text()
imgs=re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',tex)
assert len(imgs)==15, len(imgs)
assert all(Path(x).is_file() and not Path(x).is_absolute() for x in imgs)
assert '\\begin{longtable}' in tex
assert not re.search(r'/work/|/home/|/Users/|[A-Z]:[/\\]Users',tex)
assert Path('relatorio.pdf').read_bytes().startswith(b'%PDF-')
assert len(list(Path('codigo').glob('*.R')))==7
assert Path('dados/Terremoto.csv').is_file()
print('25 tabelas e 15 figuras idênticas à versão aprovada; PDF, TEX e caminhos conferidos.')
