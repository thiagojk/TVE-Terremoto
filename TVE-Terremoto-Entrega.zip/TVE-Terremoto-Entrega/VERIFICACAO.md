# Verificação da entrega — 02/11/2026

Versão científica de origem: commit `318ac44`, thiagojk/TVE-Terremoto. O projeto original foi mantido intacto. A entrega altera somente caminhos relativos e recursos/formatação necessários aos formatos locais e ao PDF.

- Reprodução desde `dados/Terremoto.csv`, executando os sete scripts ativos por `codigo/run.R` na pasta independente: aprovada. Nenhum script lê dados ou código do repositório original.
- Dados brutos e polígonos: hashes SHA-256 verificados. 23.232 terremotos analíticos; máximos anuais de 52 anos.
- Todos os 25 CSV e as 15 figuras PNG são idênticos, byte a byte, aos produtos aprovados. Hashes de referência em `tests/produtos_aprovados.json`.
- Validações estatísticas: GEV, quantis, intervalos, momentos, dependência, máximos e cobertura continental aprovadas.
- Quarto: renderização completa aprovada para HTML, Word e PDF; fonte LaTeX preservada. Últimos ajustes de paginação foram renderizados novamente no PDF usando os mesmos produtos calculados, sem alterar análises.
- PDF final: 30 páginas; 15 figuras, 14 tabelas numeradas; equações e bibliografia presentes. Proporções das imagens preservadas; todas as imagens e textos dentro das margens; revisão visual das páginas efetuada.
- LaTeX: compilação direta com XeLaTeX em duas passagens, a partir da raiz desta pasta, aprovada. Na última compilação não ocorreram avisos de rótulos duplicados, referências indefinidas, caracteres ausentes ou caixas excedendo os limites.
- HTML: links locais e âncoras verificados; teste em Chromium com acesso externo bloqueado confirmou equações MathJax locais, imagens, legendas, mapa com 738 eventos e download do DOCX correto.
- Word: pacote XML íntegro; 15 imagens incorporadas, 14 tabelas com legendas, equações nativas e referências verificadas.
- Bibliografia: 15 entradas, todas citadas; nenhuma citação sem entrada. Não foram introduzidas referências ou resultados científicos.
- Caminhos do código, QMD, configuração e TEX: relativos, sem dependência do local de trabalho original. Links bibliográficos externos são referências documentais, não arquivos necessários aos cálculos.
- Análises excluídas da versão aprovada não foram reintroduzidas. Numeração das seções, figuras e tabelas verificada.

Ambiente: R 4.5.2, Quarto 1.8.27, XeTeX/TeX Live 2023 (Ubuntu). Detalhes reais dos pacotes em `tables/sessionInfo.txt` e `renv.lock`. Pacotes e ferramentas devem estar instalados para reproduzir; restauração inicial pode exigir internet. Não há warning científico ou de renderização relevante pendente na versão final.
