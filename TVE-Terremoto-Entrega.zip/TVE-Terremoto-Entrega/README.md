# TVE-Terremoto — entrega acadêmica

**Título:** Teoria dos Valores Extremos aplicada à magnitude de terremotos.  
**Autoria declarada no relatório:** Projeto TVE-Terremoto. Não há nome individual informado.  
**Objetivo:** estudar máximos anuais globais e comparar conjuntos continentais mediante GEV, diagnósticos e níveis de retorno. Cópia da versão aprovada `318ac44`; alterações limitadas a caminhos e formatos de entrega.

## Dados e estrutura

- `dados/Terremoto.csv`: base original CSV, preservada byte a byte; 23.412 registros de 1965–2016, dos quais 23.232 terremotos entram na análise. Variáveis principais: data/hora, magnitude e escala, profundidade, latitude, longitude e identificadores/fontes.
- Procedência documentada: compilação histórica USGS/NEIC distribuída na coleção Significant Earthquakes, 1965–2016. Esta cópia não resulta de obtenção direta pelo projeto; não há comprovação de identidade integral com o ComCat atual. Evidências, fontes contribuintes e limites em `dados/PROVENIENCIA.md`.
- `dados/`: inclui ainda polígonos Natural Earth necessários aos mapas e classificação, sem download durante a análise; `checksums.json` verifica os arquivos de entrada.
- `dados/processados/`: dados tratados e objetos dos modelos, recriados pelo pipeline.
- `codigo/`: sete scripts R ativos, incluindo `01_importacao.R` (importação), funções auxiliares e `run.R` (execução completa). Análises removidas da versão aprovada não integram esta entrega.
- `tables/` e `figures/`: tabelas CSV de auditoria/resultados e 15 figuras; regenerados pelo pipeline.
- `relatorio.qmd`: fonte final; `relatorio.pdf` e `relatorio.tex`: PDF e LaTeX correspondente; HTML e Word também incluídos.
- `referencias.bib`: bibliografia; `templates/`, `filters/`, `styles.css` e `assets/`: recursos de formatação e mapa local.
- `_quarto.yml`, demais `.qmd`, `renv.lock`, `renv/` e `tests/`: configuração, ambiente e verificações.

## Reprodução

1. Extraia o ZIP e abra um terminal **na raiz desta pasta**.
2. Instale R, Quarto e uma distribuição LaTeX com XeLaTeX. Ambiente verificado: R 4.5.2 e Quarto 1.8.27; versões efetivamente carregadas em `tables/sessionInfo.txt`, versões registradas em `renv.lock`.
3. Restaure as dependências: `Rscript -e 'renv::restore(prompt=FALSE)'`. A primeira abertura ativa o bootstrap de renv e pode exigir internet para instalar pacotes. Alternativa sem renv: `Rscript --vanilla -e 'install.packages(c("evd","jsonlite","sp","knitr","rmarkdown"))'`. A análise usa evd, jsonlite e sp; a renderização usa knitr e rmarkdown, além dos pacotes base/recomendados do R.
4. Execute `Rscript codigo/run.R`. A semente é fixa. Esse comando substitui apenas produtos derivados em `dados/processados/`, `tables/`, `figures/` e `mapa.html`; não altere os dados originais.
5. Execute `quarto render --to all` para recriar HTML, DOCX, PDF e preservar o TEX. O pre-render já executa a análise; a etapa 4 pode ser omitida quando não se deseja inspecionar resultados antes da renderização.
6. Execute `Rscript tests/validate.R`, `python3 tests/validate_inputs.py`, `python3 tests/validate_html.py`, `python3 tests/validate_docx.py` `python3 tests/validate_bibliography.py` e `python3 tests/validate_delivery.py`.

Para consultar, abra `relatorio.pdf` ou `relatorio.html`. Os arquivos e recursos são locais; os links bibliográficos externos exigem internet. O mapa usa Leaflet incluído no pacote; o HTML utiliza MathJax e fontes incluídos para exibir equações sem internet em navegadores modernos. Algumas funções do navegador podem exigir servidor local: `python3 -m http.server 8000` e abrir `http://localhost:8000/`.

## PDF e LaTeX

`quarto render relatorio.qmd --to pdf` gera novamente PDF e mantém `relatorio.tex`. Requer XeLaTeX, fontes Latin Modern e pacotes LaTeX usuais de Quarto/Pandoc; em Ubuntu foram usados texlive-xetex, texlive-latex-extra, texlive-fonts-recommended, texlive-lang-portuguese e lmodern. Outra opção é `quarto install tinytex` (internet necessária).

Para compilar o TEX já incluído, execute **na raiz** `xelatex -interaction=nonstopmode -halt-on-error relatorio.tex` duas vezes. As figuras usam caminhos relativos em `figures/`; a bibliografia é incorporada pelo processamento de citações do Quarto. Para atualizar texto/citações/resultados, regenere primeiro a partir do QMD.

As tabelas largas recebem somente ajustes tipográficos no PDF. Metodologia, resultados e conclusões permanecem os da versão aprovada. O HTML preserva o estilo do site. O Word conserva links públicos suplementares, além de figuras e tabelas incorporadas; os mesmos suplementos estão disponíveis localmente nesta pasta. Diferenças entre plataformas podem produzir pequenas diferenças numéricas.
