-- Somente tipografia de identificadores longos e tamanho das figuras no PDF.
function Str(s)
  if not FORMAT:match('latex') then return nil end
  if ((#s.text >= 13 and s.text:match('^OFFICIAL')) or s.text:match('^[A-Za-z]+_[A-Za-z_]+$') or s.text=='parametro') then
    return pandoc.RawInline('latex', '\\seqsplit{' .. s.text:gsub('_','\\_') .. '}')
  end
end
function Image(im)
  if not FORMAT:match('latex') then return nil end
  im.attributes['width']='100%'
  im.attributes['height']='75%'
  return im
end
